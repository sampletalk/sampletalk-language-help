% SAMPLETALK 3.1 generated Prolog version of a Sampletalk program 
00996A50