This is SAMPLETALK language Interpreter Ver.3.1 for Windows.

Copyright (1990-2022) by Andrew Gleibman, Haifa. For a description of 
the language and technology please visit our homepage:

http://sampletalk.github.io. 

This version is for research purposes only. It is a free software 
without any guarantee. Please send your comments/questions to the author: 

Andrew H.Gleibman, PhD. Email: sampletalk(AT)gmail.com.

In this software, SWI-Prolog for Windows is used. It was kindly provided by 
Professor Jan Wielemaker from University of Amsterdam. Please visit 
http://www.swi-prolog.org/ for information about SWI-Prolog.


IMPORTANT:

Note that in the current version of Sampletalk interpreter the 1st clause
of any Sampletalk program is treated as the main program goal. All other 
clauses are considered reasoning rules for resolving this goal.

For running our initial program example AAAI205.sam, described in Section 4 
of paper www.aaai.org/Papers/Workshops/2005/WS-05-05/WS05-05-010.pdf and 
contained in the main directory of this release, simply run the batch file

COMPILE_AND_RUN_SAMPLETALK_PROGRAM.BAT.

The results of the reasoning will be printed in file OUTPUT.SAM.

For running another Sampletalk program <PName>.sam, e.g., contained in 
directory EXAMPLES, apply the same batch file, replacing parameter
AAAI205.sam with <PName>.sam (taking into account the relative path). 

Good Luck!