% SAMPLETALK 3.1 generated Prolog version of Sampletalk program AAAI205.sam

g('what',0,[
['what',spaces(' '),'is',spaces(' '),'visible',spaces(' '),'on',spaces(' '),undrl(['red',spaces(' '),'table']),sgnQuestion,spaces(' '),undrl([X])]
]). 
s('can',1,[
['can',spaces(' '),undrl([A]),spaces(' '),'see',spaces(' '),undrl([X]),sgnQuestion],
[undrl([A]),spaces(' '),'can',spaces(' '),'see',spaces(' '),undrl([X])]
]). 
s('what',2,[
['what',spaces(' '),'can',spaces(' '),undrl([A]),spaces(' '),'see',sgnQuestion,spaces(' '),undrl([X])],
[undrl([A]),spaces(' '),'can',spaces(' '),'see',spaces(' '),undrl([X])]
]). 
s('what',3,[
['what',spaces(' '),'is',spaces(' '),'in',spaces(' '),undrl([A]),sgnQuestion,spaces(' '),undrl([X])],
[undrl([X]),spaces(' '),'is',spaces(' '),'in',spaces(' '),undrl([A])]
]). 
s('what',4,[
['what',spaces(' '),'is',spaces(' '),'visible',spaces(' '),'on',spaces(' '),undrl([A]),sgnQuestion,spaces(' '),undrl([X])],
[undrl([X]),spaces(' '),'is',spaces(' '),'visible',spaces(' '),'on',spaces(' '),undrl([A])]
]). 
s('what',5,[
['what',spaces(' '),'is',spaces(' '),'invisible',spaces(' '),'on',spaces(' '),undrl([A]),sgnQuestion,spaces(' '),undrl([X])],
[undrl([X]),spaces(' '),'is',spaces(' '),'in',spaces(' '),undrl([B])],
[undrl([B]),spaces(' '),'is',spaces(' '),'on',spaces(' '),undrl([A])],
[sgnTilda,sgnTilda,undrl([X]),spaces(' '),'is',spaces(' '),'visible',spaces(' '),'on',spaces(' '),undrl([A])]
]). 
s('what',6,[
['what',spaces(' '),'is',spaces(' '),'on',spaces(' '),undrl([A]),sgnQuestion,spaces(' '),undrl([X])],
[undrl([X]),spaces(' '),'is',spaces(' '),'on',spaces(' '),undrl([A])]
]). 
s('what',7,[
['what',spaces(' '),'is',spaces(' '),'on',spaces(' '),undrl([A]),sgnQuestion,spaces(' '),undrl([X])],
[undrl([X]),spaces(' '),'is',spaces(' '),'in',spaces(' '),undrl([B])],
[undrl([B]),spaces(' '),'is',spaces(' '),'on',spaces(' '),undrl([A])]
]). 
s(undrl(_),8,[
[undrl([A]),spaces(' '),'can',spaces(' '),'see',spaces(' '),undrl([X])],
[undrl([A]),spaces(' '),'is',spaces(' '),'standing',spaces(' '),'near',spaces(' '),undrl([B])],
[undrl([X]),spaces(' '),'is',spaces(' '),'visible',spaces(' '),'on',spaces(' '),undrl([B])]
]). 
s(undrl(_),9,[
[undrl([A]),spaces(' '),'is',spaces(' '),'visible',spaces(' '),'on',spaces(' '),undrl([B])],
[undrl([A]),spaces(' '),'is',spaces(' '),'on',spaces(' '),undrl([B])]
]). 
s(undrl(_),10,[
[undrl([A]),spaces(' '),'is',spaces(' '),'visible',spaces(' '),'on',spaces(' '),undrl([B])],
[undrl([A]),spaces(' '),'is',spaces(' '),'in',spaces(' '),undrl(['open',spaces(' '),X])],
[undrl(['open',spaces(' '),X]),spaces(' '),'is',spaces(' '),'visible',spaces(' '),'on',spaces(' '),undrl([B])]
]). 
s(undrl(_),11,[
[undrl([A]),spaces(' '),'is',spaces(' '),'standing',spaces(' '),'near',spaces(' '),undrl([B])],
[undrl([A]),spaces(' '),'has',spaces(' '),'approached',spaces(' '),undrl([B])]
]). 
s(undrl(_),12,[
[undrl(['book']),spaces(' '),'is',spaces(' '),'in',spaces(' '),undrl(['open',spaces(' '),'box'])]
]). 
s(undrl(_),13,[
[undrl(['notebook']),spaces(' '),'is',spaces(' '),'in',spaces(' '),undrl(['closed',spaces(' '),'box'])]
]). 
s(undrl(_),14,[
[undrl(['open',spaces(' '),'box']),spaces(' '),'is',spaces(' '),'on',spaces(' '),undrl(['red',spaces(' '),'table'])]
]). 
s(undrl(_),15,[
[undrl(['closed',spaces(' '),'box']),spaces(' '),'is',spaces(' '),'on',spaces(' '),undrl(['red',spaces(' '),'table'])]
]). 
s(undrl(_),16,[
[undrl(['john']),spaces(' '),'has',spaces(' '),'approached',spaces(' '),undrl(['red',spaces(' '),'table'])]
]). 