%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% 	SAMPLETALK Interpreter, Ver. 3.1.
% 	Copyright (1985-2022) by Andrew Gleibman, Haifa. For the description of 
%	the language and technology please visit http://sampletalk.github.io. 
% 	This version is for research purposes only, and it is a free software 
% 	without any guarantee. Please send your comments/questions to the author: 
% 	Andrew H. Gleibman, PhD. Email: sampletalk(AT)gmail.com.
% 	In this software, SWI-Prolog for Windows is used. It was kindly provided by 
% 	Professor Jan Wielemaker from University of Amsterdam. Please visit 
% 	http://www.swi-prolog.org/ for information about SWI-Prolog.
%
%	Note that in the current version of Sampletalk interpreter the 1st Sampletalk clause
%	of any program (Head without Subgoals) is treated as the main program goal.
%
%	For interpreting a Sampletalk program stored in file <pname>.sam, please compile it 
%	into Prolog using the batch file
%
%		CompileSampletalkToPrologConsoleApp.bat
%
%	with <pname>.sam inserted as a parameter for the module CompileSampletalkToPrologConsoleApp.exe.
%
%	As the result you will get a file a_s1.pl.
%
%	Then, launch SWI Prolog, consult Prolog programs
%
%	sampletalk3_1.pl (this file),
%
%	and print
%
%	gg.
%
%	As the result, your program <pname>.sam will be interpreted.  
%

% Modes for running Sampletalk interpreter (please comment/uncomment out any of them to change a mode):

m(write_intermediate_results).	% printing intermediate Sampletalk inference results (verbosity control)
m(output_to_file_output_sam).	% the inference output will bi written into file "output.sam"
m(backtracking_sensitivity).	% all possibilities of pairvise matching samples are considered
m(stop_between_lines).		% the inference will stop until the user presses any key
m(all_decisions).		% all possible decifions of Sampletalk goal will be found

scompile :- qsave_program('run_a_s1.exe',[goal(gg)]).


% Main Prolog goal for interpreting the consulted Prolog version of current Sampletalk program:
gg :-	['a_s1.pl'],
	write('SAMPLETALK Ver.3.1 Output:\n\n'),
	samplerg, % resolve the goal
	write('\nPress any key to finish...'),get_single_char(_),halt.

samplerg :- 
	ifthen(m(output_to_file_output_sam),
		(
			write('\nOutput is being written into file OUTPUT.SAM...\n'),
			working_directory(WDir,WDir),
			atom_concat(WDir, 'OUTPUT.SAM', OutFileLoc),
			tell(OutFileLoc)				
		)
	),
	g(_,_,[G]), % accessing the program goal
	ifthen(m(interrupted),
		(write1('\nINTERRUPTED.'),!,fail)),
	write('\nRESOLVING GOAL: \n'),writelist(G),nl,
	resolve_current_goal(G),
	fail.
samplerg :- not(g(_,_,_)),
	write1('There are not goals in memory. 1-st clause of a consulted file is'),nl,
	write1('considered a goal. You may prepare a list of goals in file GOALS.SAM'),nl,
	write1('and then tune the interpreter for resolving goals from this file'),!.
samplerg :- ifthen(m(interrupted),
		(!,write1('\nINTERRUPTED.\n'))),
	told,write1('->').

resolve_current_goal(_) :- 
	m(interrupted), 
	write1('\nINTERRUPTED.\n'),!.			 
resolve_current_goal(G) :- 
	resolve(G), nl,
	ifthenelse(m(interrupted),
		true,
		(writelist(G),write1('\nTHE GOAL RESOLVED. \n\nTRYING TO FIND ADDITINAL DECISIONS:'))),
	ifthen(m(all_decisions),
		(wait_unconditional,fail)),!.
resolve_current_goal(_) :-
	write1('\nNO MORE DECISIONS FOUND...\n').  

resolve(_):- m(interrupted),!.
resolve(G):- 
	ifthenelse(
		m(all_decisions), 
		res(G), 	% looking for all possible decisions
		(res(G),!) 	% looking for a single decision
	).

neg_or_print([sgnTilda|L]) :- 
	ifthen(m(write_intermediate_results),
		(nl,write1('not: '))),
	ifthen(m(write_intermediate_results),
		(write1('negation of '),writelist(L))),
	resolve(L),!,
	ifthen(m(write_intermediate_results),
		(writelist(L),write1(' negation fails. '))),
	!,fail.
neg_or_print([sgnTilda|_]) :- !,
	ifthen(m(write_intermediate_results),
		(write1(' negation succeed. '))).
neg_or_print([sgnDblQuote|L]):-!,
	resolve(L),nl,
	writelist(L).

res([A|L]) :- nonvar(A),A=sgnTilda,!,neg_or_print(L).
res([pr_term(X)]) :- 
	ifthen( m(write_intermediate_results),
		(nl,write1('Prolog Call:'),write1(X))),
	call(X),!, 
	ifthen(m(write_intermediate_results),
		(write1('\nOK.\n'))),!,wait.
res([pr_term(_)]) :- !,
	ifthen(m(write_intermediate_results),
		(write1('\nFail...'))),wait,fail.
res(_) :-m(interrupted),!.
res(G) :-simplify(G,Gs),
	retrieve2_key(Gs,R_key),
	s(R_key,N,[H|B]),
       	match(Gs,H),
        ifthen(m(write_intermediate_results),
		(nl,writelist(Gs),write1('  ?'),wait)),
        reslist(B).
res([]).

reslist([]). 
reslist([G|Rest]) :- 
	resolve(G), 
	reslist(Rest).   

match(_,_) :- m(interrupted),!.
match(G,H) :- simplify(H,H1),
	ifthenelse(m(backtracking_sensitivity), 
		match2(G,H1), 
		(match2(G,H1),!)).  

match2([A|L1],[B|L2]) :- mtch(A,B), match2(L1,L2).
match2([M|L1],L2) :- append1(M,L3,L2), match2(L1,L3).
match2(L2,[M|L1]) :- append1(M,L3,L2), match2(L3,L1).
match2([],[]).

mtch(A,B):-var(A),A=B,!.
mtch(A,B):-var(B),A=B,!.
mtch(A,B):-A=B,!.
mtch(undrl(A),undrl(B)):-!,match(A,B).
mtch(spaces(_),spaces(_)):-!.

append1([A,B],L,[A,B|L]). 
append1([X|L1],L2,[X|L3]) :- append1(L1,L2,L3).

writelist(A):-!,wrtelist(A),!.
wrtelist(A):-var(A),!,write1('_'),!. 
wrtelist(undrl(X)):-!,write1('['),!,wrtelist(X),!,write1(']'),!.
wrtelist(pr_term(X)):-!,write1('{'),!,wrtelist(X),write1('}'),!.
wrtelist([A|B]):-!,wrtelist(A),!,wrtelist(B),!.
wrtelist([]):-!.
wrtelist(0' ):-!,write1(' '),!.
wrtelist(A):-atom(A),!,write1(A),!.
wrtelist(A):-!,write1(A).

simplify([],[]) :-!.
simplify([A|B],[A|C]) :- var(A),!,simplify(B,C),!.
simplify([undrl(X)|B],[undrl(Y)|C]):-!,simplify(X,Y),!,simplify(B,C),!.
simplify([[A|B]|C],L) :- !,simplify([A|B],AB),!,simplify(C,Rest),!,append(AB,Rest,L),!.
simplify([A|B],[A|C]) :- !,simplify(B,C),!.

ifthenelse(A,B,_) :- call(A),!,call(B). 
ifthenelse(A,_,C) :- not(A),!,call(C). ifthenelse(_,_,_).
ifthen(A,B) :- call(A),!,call(B). ifthen(_,_).

retrieve2_key([A|_],_):-var(A),!.		% Pr.var at beginning.
retrieve2_key([undrl(_)|_],undrl(_)):-!.	% underlined beginning.
retrieve2_key([pr_term(_)|_],pr_term(_)):-!.	% Pr.term at beginning.
retrieve2_key([A|_],A):-atom(A).		% Pr.atom at beginning.

wait_unconditional:-m(output_to_file_output_sam),!.
wait_unconditional:-write('\nPress any key to continue...'),get_single_char(_).
wait:-m(output_to_file_output_sam),!.
wait:-m(stop_between_lines),m(write_intermediate_results),!,
	write('\nPress any key to continue...'),get_single_char(_).
wait.

write1(spaces(X)):-		write(X).
write1(sgnTilda):-		write('~').
write1(sgnOpenQuote):-		write('`').
write1(sgnExclamation):-	write('!').
write1(sgnAt):-			write('&').
write1(sgnDies):-		write('#').
write1(sgnDollar):-		write('$').
write1(sgnPercent):-		write('%').
write1(sgnHat):-		write('^').
write1(sgnAmpersand):-		write('&').
write1(sgnAsterisk):-		write('*').
write1(sgnOpenBracket):-	write('(').
write1(sgnCloseBracket):-	write(')').
write1(sgnMinus):-		write('-').
write1(sgnPlus):-		write('+').
write1(sgnEqual):-		write('=').
write1(sgnStick):-		write('|').
write1(sgnBckSlash):-		write('\\').
write1(sgnColon):-		write(':').
write1(sgnSemicolon):-		write(';').
write1(sgnDblQuote):-		write('"').
write1(sgnQuote):-		write('\'').
write1(sgnLess):-		write('<').
write1(sgnGreater):-		write('>').
write1(sgnComma):-		write(',').
write1(sgnDot):-		write('.').
write1(sgnQuestion):-		write('?').
write1(sgnSlash):-		write('/').
write1(S):-			write(S).
