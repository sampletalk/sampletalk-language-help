This is SAMPLETALK language Interpreter Ver. 3.0.

Copyright (1990-2022) by Andrew Gleibman, Haifa. For a description of 
the language and the technology please visit 

http://sampletalk.github.io. 

This version is for research purposes only. It is a free software 
without any guarantee. Please send your comments/questions to the author: 

Andrew H.Gleibman, PhD. Email: sampletalk(AT)gmail.com.

In this software SWI-Prolog for Windows is used. It was kindly provided by 
Professor Jan Wielemaker from University of Amsterdam. Please visit 
http://www.swi-prolog.org/ for the information about SWI-Prolog.

Note that, in the current version of Sampletalk interpreter, the 1st clause
of any Sampletalk program is treated as the main program goal. All other 
clauses present reasoning rules for resolving the goal.

For interpreting a Sampletalk program <PName>.sam, contained in 
directory EXAMPLES), please compile it into a Prolog code using batch file

CompileSampletalkToPrologConsoleApp.bat

with path-name <PName>.sam inserted, taking into account the relative path, 
as an input parameter for the module CompileSampletalkToPrologConsoleApp.exe,
which is the Sampletalk-to-Prolog compiler. As the result you will get, 
in the same directory, a file <PName>.pl.

Then you only need to launch SWI Prolog and consult Prolog programs

sampletalk3.pl
<pname>.pl.

After this, in SWI Prolog dialog, print

gg.

As the result, your program <pname>.sam will be interpreted, and you will see
the results of the reasoning in the SWI Prolog window.

Explanation of the modes for running Sampletalk interpreter, which are defined
in source file sampletalk3.pl:

m(write_intermediate_results).	% printing intermediate Sampletalk inference results (verbosity control)
m(output_to_file_output_sam).	% the inference output will bi written into file "output.sam"
m(backtracking_sensitivity).	% all possibilities of pairvise matching samples are considered
m(stop_between_lines).		% the inference will stop until the user presses any key
m(all_decisions).		% all possible decifions of Sampletalk goal will be found

The folder also contains a Visual C++ application 
CompileSampletalkToPrologConsoleApp for generating the 
Sampletalk-to-Prolog compiler.


Good Luck!