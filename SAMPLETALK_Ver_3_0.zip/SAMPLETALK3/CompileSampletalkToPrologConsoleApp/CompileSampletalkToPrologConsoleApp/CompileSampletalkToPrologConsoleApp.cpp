// CompileSampletalkToPrologConsoleApp.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <atlstr.h>
#include <fstream>
#include <iostream>
using namespace std;

CString csDocName; // = "C:/Andrew/_sampletalk_theory/_Sampletalk_compiler_SWIProlog/AAAI205.sam";
CString csOutputPrologCode; // = "C:/Andrew/_sampletalk_theory/_Sampletalk_compiler_SWIProlog/a_s1.pl";
BOOL b_write_intermediate_results = 0;
BOOL b_output_to_file_output_sam = 0;
BOOL b_backtracking_sensitivity = 0;
BOOL b_stop_between_lines = 0;
BOOL b_all_decisions = 0;

void TranslateSampleToProlog();
CString TakeFirstWord(CString csSampleText1);
CString RepairPrologClause(CString csClause);
CString csTranslateSampleClause(CString csSampleClause); // Compile current Sampletalk clause into Prolog and return the result
CString csDesignationOf(char Ch);
CString cs_g_s_prefix; // "g(" for Sampletalk goal, "s(" for Sampletalk clause.
int nClauseNumber; 

int compileSTtoPROLOG()
{
	TranslateSampleToProlog();
	return 1;
}

CString csDesignationOf(char Ch) // Representing special characters, occurred in Sampletalk code, as Prolog constants:
{
	switch (Ch)
	{
		case '~' : return "sgnTilda";
		case '`' : return "sgnOpenQuote";
		case '!' : return "sgnExclamation";
		case '@' : return "sgnAt";
		case '#' : return "sgnDies";
		case '$' : return "sgnDollar";
		case '%' : return "sgnPercent";
		case '^' : return "sgnHat";
		case '&' : return "sgnAmpersand";
		case '*' : return "sgnAsterisk";
		case '(' : return "sgnOpenBracket";
		case ')' : return "sgnCloseBracket";
		case '-' : return "sgnMinus";
		case '+' : return "sgnPlus";
		case '=' : return "sgnEqual";
		case '|' : return "sgnStick";
		case '\\': return "sgnBckSlash";
		case ':' : return "sgnColon";
		case ';' : return "sgnSemicolon";
		case '\"': return "sgnDblQuote";
		case '\'': return "sgnQuote";
		case '<' : return "sgnLess";
		case '>' : return "sgnGreater";
		case ',' : return "sgnComma";
		case '.' : return "sgnDot";
		case '?' : return "sgnQuestion";
		case '/' : return "sgnSlash";
		default	 : return "sgnUnknownChar"; 
	}
}

void TranslateSampleToProlog()
{
  CString csSampleClause = ""; // current Sampletalk clause
  CString csPrologClause = ""; // its Prolog translation
  cs_g_s_prefix = "\ng(";      // Prolog translation of a Sampletalk goal starts from "g(";
  nClauseNumber=0;
  ifstream infile; 
  infile.open(csDocName);
  
  ofstream outfile;
  int n = csDocName.Find('.'); // replace extension "sam" by "pl" 
  if (n > 0)
	  csOutputPrologCode = csDocName.Mid(0,n) + ".pl";
  else
	  return;
  outfile.open(csOutputPrologCode);

  // File csOutputPrologCode will store Prolog translation of the currently opened Sampletalk program:
    outfile << "% SAMPLETALK 3.0 generated Prolog version of a Sampletalk program\n";

  // Store current Sampletalk interface options for Sampletalk interpreter:

  //if (b_write_intermediate_results)		outfile  << "m(write_intermediate_results).\n";
  //if (b_output_to_file_output_sam)		outfile  << "m(output_to_file_output_sam).\n";
  //if (b_backtracking_sensitivity)		outfile  << "m(backtracking_sensitivity).\n";
  //if (b_stop_between_lines)				outfile  << "m(stop_between_lines).\n";
  //if (b_all_decisions)					outfile  << "m(all_decisions).\n"; 

  // Sequentially read and translate Sampletalk goal and then clauses:
  CString csLastScan=""; // for finding Sampletalk syntax markers ":-", ",,", ".."
  char szBuf[255] = "";  // for reading document lines
  while (!infile.eof())
  {
    infile.getline(szBuf,255,'\n');
	if (szBuf[0] != '%')
	{
	  for (int i=0; i<255; i++)
	  {
		if (szBuf[i] == '%') 
			break;
		if (szBuf[i] == '\0') 
			break;
		csSampleClause+= CString(szBuf[i]);	
		csLastScan = csSampleClause.Right(2);
		if ((csLastScan == ":-") || (csLastScan == ",,") || (csLastScan == ".."))
		{
			csSampleClause = csSampleClause.Left(csSampleClause.GetLength()-2);
			csSampleClause.TrimRight();
			csSampleClause+= csLastScan;
			if (csLastScan == "..") 
			{
				csSampleClause.TrimLeft();
				csPrologClause = csTranslateSampleClause(csSampleClause);
				char cChar[1024];
				sprintf_s(cChar,"%s",CW2A(csPrologClause));
				outfile << cChar;
				cs_g_s_prefix = "\ns("; // Prolog translation of a Sampletalk clauses will start from "s(";
				csSampleClause = ""; 
			}
		}
	  }
	  csSampleClause += '\n';
	}
  }
  csSampleClause+="\n% ##### ##### ##### ##### #####";
}

CString TakeFirstWord(CString csSampleText1)
{
	int n = 0;
	CString csWord = "";
	while (n < csSampleText1.GetLength()-15) 
	{
		if(isalpha(csSampleText1[n]) || isdigit(csSampleText1[n]) || csSampleText1[n] == '_')
		{
			csWord+=csSampleText1[n];
			n++;
		}
		else 
			break;
	}
	if (csWord != "") 
		return "\'" + csWord + "\'";
	else if (csSampleText1[n] == '[')		
		return "undrl(_)";   
	else if (csSampleText1[n] == '{')		
		return "pr_term(_)";   
	else
		return csDesignationOf(csSampleText1[n]);
}


// Additional adjustments to conform to Prolog syntax: 
// transform ",," to ","         "()" to "(' ')"        ",]" to "]" etc: 
CString RepairPrologClause(CString csClause)
{
	CString csClause0 = csClause + " ..............";
	CString csClause1 = "";
	int i=0;
	while (i < csClause0.GetLength()-10)
	{
		if (csClause0.Mid(i,6) == "......")	
			return csClause1;
		else if (csClause0.Mid(i,9) == "pr_term()")	
			{csClause1+="pr_term(' ')"; i+=9;}
		else if (isalpha(csClause0[i])) 
			csClause1+=csClause0[i++];
			else if (csClause0.Mid(i,7) == ",,' ',]")	
			{csClause1+="]"; i+=7;}
		else if (csClause0.Mid(i,7) == ",,' ',}")	
			{csClause1+="}"; i+=7;}
		else if (csClause0.Mid(i,6) == ",' ',]")	
			{csClause1+="]"; i+=6;}
		else if (csClause0.Mid(i,6) == ",' ',}")	
			{csClause1+="}"; i+=6;}
		else if (csClause0.Mid(i,5) == "' ',]")	
			{csClause1+="]"; i+=5;}
		else if (csClause0.Mid(i,5) == "' ',}")	
			{csClause1+="}"; i+=5;}
		else if (csClause0.Mid(i,3) == ", ]")
			{csClause1+="]"; i+=3;}
		else if (csClause0.Mid(i,3) == ", }")	
			{csClause1+="}"; i+=3;}
		else if (csClause0.Mid(i,2) == "[,")
			{csClause1+="["; i+=2;}
		else if (csClause0.Mid(i,2) == ",]")	
			{csClause1+="]"; i+=2;}
		else if (csClause0.Mid(i,2) == "{,")
			{csClause1+="{"; i+=2;}
		else if (csClause0.Mid(i,2) == ",}")	
			{csClause1+="}"; i+=2;}
		else if (csClause0.Mid(i,2) == ",,")	
			{csClause1+=","; i+=2;}
		else 
			{csClause1+= csClause0[i]; i+=1;}
	}
	return csClause1;
}

CString csTranslateSampleClause(CString csSampleClause) // Compile current Sampletalk clause into Prolog and return the result
{
	int nCh0=0;
	csSampleClause+="\n% ##### ##### ##### ##### #####";
	CString csOutClause ="";
	CString Ch,Ch1;
	CString csConst;
	int nLenght = csSampleClause.GetLength();
	bool bClauseBeginning = true;
  
	while (nCh0 < nLenght-15) 
	{
		Ch = csSampleClause.Mid(nCh0,1);

		if (bClauseBeginning) 
		{
			csOutClause+= cs_g_s_prefix + TakeFirstWord(csSampleClause) +",";
			char szNumBuf[255];
			sprintf_s(szNumBuf,"%d",nClauseNumber++);
			csOutClause+= szNumBuf;
			csOutClause+= ",[\n[";
			bClauseBeginning = false;
		}
	
		if (csSampleClause.Mid(nCh0,2) == "..") 
		{
			csOutClause+= "]\n])."; 
			bClauseBeginning = true;
			return RepairPrologClause(csOutClause); 
		}		
		else if (csSampleClause.Mid(nCh0,2) == ",,") 
		{
			csOutClause+= "],\n["; 
			nCh0+=2; 
			//skip spaces:
			while ((nCh0 < nLenght-15) && ((csSampleClause[nCh0] == ' ') || (csSampleClause[nCh0] == '\t') || (csSampleClause[nCh0] == '\r') || (csSampleClause[nCh0] == '\n') )) 
				nCh0++;
		}		
		else if (csSampleClause.Mid(nCh0,2) == ":-") 
		{
			csOutClause+= "],\n["; 
			nCh0+=2; 
			//skip spaces:
			while ((nCh0 < nLenght-15) && ((csSampleClause[nCh0] == ' ') || (csSampleClause[nCh0] == '\t') || (csSampleClause[nCh0] == '\r') || (csSampleClause[nCh0] == '\n') )) 
				nCh0++;
		}		
		else if	(Ch == '[')	{csOutClause+= ",undrl(["; nCh0++;}
		else if (Ch == ']') {csOutClause+= "]),"; nCh0++;}
		else if (Ch == '{') 
		{
			csOutClause+= ",pr_term("; nCh0++;
			while ((nCh0 < nLenght-15) && (csSampleClause[nCh0] != '}'))
				csOutClause+= csSampleClause[nCh0++];
			csOutClause+= "),";
			nCh0++;
		}
		else if ((Ch == ' ') || (Ch == '\t') || (Ch == '\n') || (Ch == '\r'))
		{
			csOutClause+= ",spaces('";
			csOutClause+= Ch;
			nCh0++;	
			//collect and skip all kind of spaces:
			while ((nCh0 < nLenght-15) && ((csSampleClause[nCh0] == ' ') || (csSampleClause[nCh0] == '\t') || (csSampleClause[nCh0] == '\r') || (csSampleClause[nCh0] == '\n') ))
			{
				csOutClause+= csSampleClause[nCh0];
				nCh0++;
			}
			csOutClause+= "'),";
		}
		else if (islower(Ch[0]) || isdigit(Ch[0])) // take "const"
		{
			csConst = "";
			while (nCh0 < csSampleClause.GetLength()-15) 
			{
				if(isalpha(csSampleClause[nCh0]) || isdigit(csSampleClause[nCh0]) || csSampleClause[nCh0] == '_')
				{
					csConst+=csSampleClause[nCh0];
					nCh0++;
				}
				else break;
			}
			csOutClause+= ",\'" + csConst + "\',";
		}
		else if (isupper(Ch[0]) || (Ch == "_")) // take Sample variable
		{
			csConst = "";
			while (nCh0 < csSampleClause.GetLength()-15) 
			{
				if(isalpha(csSampleClause[nCh0]) || isdigit(csSampleClause[nCh0]) || csSampleClause[nCh0] == '_')
				{
					csConst+=csSampleClause[nCh0];
					nCh0++;
				}
				else break;
			}
			csOutClause+= "," + csConst + ",";
		}
		else	// take special character
		{ 
			csOutClause+= "," + csDesignationOf(Ch[0]) + ",";
			nCh0++;		
		}
	}
	return "";
}


int main(int argc, char *argv[]) 
{
	//ofstream outfile;
	//outfile.open("test.txt");
	//outfile << "There are " << argc << " arguments:" << endl;
	//for (int i=0; i<argc; i++)
	//	outfile << i << " " << argv[i] << endl;
	//return 0;

	if (argc < 2)
		return 0;

	csDocName						= CString(argv[1]);
	TranslateSampleToProlog();
	return 1;
}

